TOP_DIR = '/home/harry/airflow/dags/outputs'
CURRENT_DIR = '/home/harry/airflow/dags/outputs'

DB_NAME = 'test.db'

BATCH_SIZE = 32
NUM_EPOCHS = 10
LEARNING_RATE = 0.001
USE_ATTENTION = True
